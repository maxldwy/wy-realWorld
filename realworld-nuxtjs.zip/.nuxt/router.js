import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _c2e04130 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _0cadd09d = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _ed76e92a = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _23762d2b = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _46e0ee3e = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _da7df4aa = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _0a407078 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _c2e04130,
    children: [{
      path: "",
      component: _0cadd09d,
      name: "home"
    }, {
      path: "/login",
      component: _ed76e92a,
      name: "login"
    }, {
      path: "/register",
      component: _ed76e92a,
      name: "register"
    }, {
      path: "/profile/:username/:tab?",
      component: _23762d2b,
      name: "profile"
    }, {
      path: "/settings",
      component: _46e0ee3e,
      name: "settings"
    }, {
      path: "/editor/:slug?",
      component: _da7df4aa,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _0a407078,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
